package com.scenerebuilt.core

import com.scenerebuilt.root.RootShell
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class SchedMode(val name: String, val desc: String) {
    HP("高性能", "最大性能释放"),
    BALANCED("均衡", "平衡性能与发热"),
    EP("节能", "降低功耗温度"),
    SILENT("静音", "极限省电")
}

data class CpuState(val id: Int, val freqKhz: Long, val maxKhz: Long)
data class GpuState(val freqMhz: Long)
data class TempState(val type: String, val tempC: Float)

class SceneEngine {
    
    private val _cpuStates = MutableStateFlow<List<CpuState>>(emptyList())
    val cpuStates: StateFlow<List<CpuState>> = _cpuStates
    
    private val _gpuState = MutableStateFlow<GpuState?>(null)
    val gpuState: StateFlow<GpuState?> = _gpuState
    
    private val _temps = MutableStateFlow<List<TempState>>(emptyList())
    val temps: StateFlow<List<TempState>> = _temps
    
    var currentMode = SchedMode.BALANCED
    var refreshRateHz = 60
    var thermalDisabled = false
    var gpuLocked = false
    
    suspend fun setMode(mode: SchedMode): Boolean {
        currentMode = mode
        return when (mode) {
            SchedMode.HP -> enableHP()
            SchedMode.EP -> enableEP()
            else -> enableBalanced()
        }
    }
    
    private suspend fun enableHP(): Boolean {
        val cmds = listOf(
            "for d in /sys/devices/system/cpu/cpu*/cpufreq/scaling_min_freq; do max=\$(cat \$(dirname \$d)/cpufreq/cpuinfo_max_freq); echo \$max > \$d 2>/dev/null; done",
            "echo '0' > /sys/class/kgsl/kgsl-3d0/min_pwrlevel 2>/dev/null",
            "echo '1' > /sys/class/kgsl/kgsl-3d0/force_clk_on 2>/dev/null",
            "echo '1' > /sys/class/kgsl/kgsl-3d0/force_bus_on 2>/dev/null",
            "stop mi_thermald 2>/dev/null; stop thermal-engine 2>/dev/null",
            "stop perfd 2>/dev/null; stop miuibooster 2>/dev/null",
            "for d in /sys/class/devfreq/*gpu*; do [ -f \$d/min_freq ] && max=\$(cat \$d/max_freq 2>/dev/null) && [ -n \"\$max\" ] && echo \$max > \$d/min_freq 2>/dev/null; done"
        )
        return cmds.any { RootShell.execOk(it) }
    }
    
    private suspend fun enableEP(): Boolean {
        val cmds = listOf(
            "for d in /sys/devices/system/cpu/cpu*/cpufreq/scaling_min_freq; do echo '800000' > \$d 2>/dev/null; done",
            "echo '3' > /sys/class/kgsl/kgsl-3d0/min_pwrlevel 2>/dev/null",
            "start mi_thermald 2>/dev/null; start thermal-engine 2>/dev/null"
        )
        return cmds.any { RootShell.execOk(it) }
    }
    
    private suspend fun enableBalanced(): Boolean {
        val cmds = listOf(
            "for d in /sys/devices/system/cpu/cpu*/cpufreq/scaling_min_freq; do max=\$(cat \$(dirname \$d)/cpufreq/cpuinfo_max_freq 2>/dev/null); min=\$((max / 2)); echo \$min > \$d 2>/dev/null; done",
            "echo '1' > /sys/class/kgsl/kgsl-3d0/min_pwrlevel 2>/dev/null"
        )
        return cmds.any { RootShell.execOk(it) }
    }
    
    suspend fun setRefreshRate(hz: Int): Boolean {
        refreshRateHz = hz
        return RootShell.execOk("svc power set-refresh-rate $hz") ||
               RootShell.execOk("echo '$hz' > /sys/class/graphics/fb0/refresh_rate 2>/dev/null")
    }
    
    suspend fun getCurrentRefreshRate(): Int {
        return RootShell.readFile("/sys/class/graphics/fb0/refresh_rate").toIntOrNull() ?: 60
    }
    
    suspend fun setUperfMode(mode: String): Boolean {
        val entry = RootShell.readFile("/data/powercfg.json")
            .let { json -> Regex("\"entry\"\\s*:\\s*\"([^\"]+)\"").find(json)?.groupValues?.get(1) ?: "/data/powercfg.sh" }
        return if (entry.isNotEmpty()) RootShell.execOk("sh $entry $mode")
        else RootShell.execOk("echo '$mode' > /sdcard/Android/yc/uperf/cur_powermode.txt")
    }
    
    suspend fun disableThermal(): Boolean {
        thermalDisabled = true
        return RootShell.execOk("killall -9 mi_thermald 2>/dev/null; killall -9 thermal-engine 2>/dev/null; echo '0' > /sys/module/msm_thermal/core_control/enabled 2>/dev/null")
    }
    
    suspend fun enableThermal(): Boolean {
        thermalDisabled = false
        return RootShell.execOk("start mi_thermald 2>/dev/null; start thermal-engine 2>/dev/null; echo '1' > /sys/module/msm_thermal/core_control/enabled 2>/dev/null")
    }
    
    suspend fun optimizeIO(): Boolean {
        return RootShell.execOk("echo 'noop' > /sys/block/mmcblk0/queue/scheduler 2>/dev/null; echo '2048' > /sys/block/mmcblk0/queue/read_ahead_kb 2>/dev/null")
    }
    
    suspend fun updateStats() {
        val cpus = mutableListOf<CpuState>()
        for (i in 0..7) {
            val freq = RootShell.readFile("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq").toLongOrNull() ?: 0
            val max = RootShell.readFile("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq").toLongOrNull() ?: 0
            if (max > 0) cpus.add(CpuState(i, freq, max))
        }
        _cpuStates.value = cpus
        
        val gpu = RootShell.readFile("/sys/class/devfreq/soc\\:qcom,gpubw/format_stat").toLongOrNull()
            ?: RootShell.readFile("/sys/class/kgsl/kgsl-3d0/gpublock_clock_speed").toLongOrNull() ?: 0
        _gpuState.value = if (gpu > 0) GpuState(gpu / 1000) else null
        
        val temps = mutableListOf<TempState>()
        for (i in 0..15) {
            val type = RootShell.readFile("/sys/class/thermal/thermal_zone$i/type")
            if (type.isNotBlank()) {
                val temp = RootShell.readFile("/sys/class/thermal/thermal_zone$i/temp").toFloatOrNull() ?: 0f
                temps.add(TempState(type, temp / 1000f))
            }
        }
        _temps.value = temps
    }
}
