package com.scenerebuilt

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.scenerebuilt.core.SchedMode
import com.scenerebuilt.core.SceneEngine
import com.scenerebuilt.overlay.FpsOverlayService
import com.scenerebuilt.root.RootShell
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    
    private lateinit var tvStatus: TextView
    private lateinit var tvCPUCores: TextView
    private lateinit var tvCPUFreq: TextView
    private lateinit var tvGPUFreq: TextView
    private lateinit var tvTemp: TextView
    
    private lateinit var btnHP: Button
    private lateinit var btnBalanced: Button
    private lateinit var btnEP: Button
    private lateinit var btnSilent: Button
    
    private lateinit var swRefresh: Switch
    private lateinit var swSched: Switch
    private lateinit var swThermal: Switch
    private lateinit var swGPU: Switch
    private lateinit var swIO: Switch
    private lateinit var swFPS: Switch
    
    private val engine = SceneEngine()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        bindViews()
        setupListeners()
        checkRoot()
    }
    
    private fun bindViews() {
        tvStatus = findViewById(R.id.tv_status)
        tvCPUCores = findViewById(R.id.tv_cpu_cores)
        tvCPUFreq = findViewById(R.id.tv_cpu_freq)
        tvGPUFreq = findViewById(R.id.tv_gpu_freq)
        tvTemp = findViewById(R.id.tv_temp)
        
        btnHP = findViewById(R.id.btn_hp)
        btnBalanced = findViewById(R.id.btn_balanced)
        btnEP = findViewById(R.id.btn_ep)
        btnSilent = findViewById(R.id.btn_silent)
        
        swRefresh = findViewById(R.id.sw_refresh)
        swSched = findViewById(R.id.sw_sched)
        swThermal = findViewById(R.id.sw_thermal)
        swGPU = findViewById(R.id.sw_gpu)
        swIO = findViewById(R.id.sw_io)
        swFPS = findViewById(R.id.sw_fps)
    }
    
    private fun setupListeners() {
        btnHP.setOnClickListener { selectMode(SchedMode.HP) }
        btnBalanced.setOnClickListener { selectMode(SchedMode.BALANCED) }
        btnEP.setOnClickListener { selectMode(SchedMode.EP) }
        btnSilent.setOnClickListener { selectMode(SchedMode.SILENT) }
        
        swRefresh.setOnCheckedChangeListener { _, checked ->
            lifecycleScope.launch { engine.setRefreshRate(if (checked) 144 else 60) }
        }
        
        swSched.setOnCheckedChangeListener { _, checked ->
            lifecycleScope.launch { if (checked) engine.enableHP() else engine.enableBalanced() }
        }
        
        swThermal.setOnCheckedChangeListener { _, checked ->
            lifecycleScope.launch { if (checked) engine.disableThermal() else engine.enableThermal() }
        }
        
        swGPU.setOnCheckedChangeListener { _, checked ->
            lifecycleScope.launch { if (checked) engine.enableHP() else engine.enableBalanced() }
        }
        
        swIO.setOnClickListener {
            lifecycleScope.launch { engine.optimizeIO() }
        }
        
        swFPS.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                if (Settings.canDrawOverlays(this)) {
                    FpsOverlayService.start(this)
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                    swFPS.isChecked = false
                }
            } else {
                FpsOverlayService.stop(this)
            }
        }
    }
    
    private fun selectMode(mode: SchedMode) {
        lifecycleScope.launch {
            if (engine.setMode(mode)) {
                Toast.makeText(this@MainActivity, "${mode.name} 模式已启用", Toast.LENGTH_SHORT).show()
                updateModeButtons(mode)
            }
        }
    }
    
    private fun updateModeButtons(selected: SchedMode) {
        val onColor = 0xFFE65100.toInt()
        val offColor = 0xFF757575.toInt()
        
        btnHP.setTextColor(if (selected == SchedMode.HP) onColor else offColor)
        btnBalanced.setTextColor(if (selected == SchedMode.BALANCED) onColor else offColor)
        btnEP.setTextColor(if (selected == SchedMode.EP) onColor else offColor)
        btnSilent.setTextColor(if (selected == SchedMode.SILENT) onColor else offColor)
    }
    
    private fun checkRoot() {
        lifecycleScope.launch {
            val hasRoot = RootShell.isRoot()
            withContext(Dispatchers.Main) {
                if (hasRoot) {
                    tvStatus.text = "Root 已获取 ✓"
                    tvStatus.setTextColor(0xFF4CAF50.toInt())
                    enableUI(true)
                    startMonitoring()
                } else {
                    tvStatus.text = "需要 Root 权限"
                    tvStatus.setTextColor(0xFFF44336.toInt())
                    enableUI(false)
                }
            }
        }
    }
    
    private fun enableUI(enabled: Boolean) {
        swRefresh.isEnabled = enabled
        swSched.isEnabled = enabled
        swThermal.isEnabled = enabled
        swGPU.isEnabled = enabled
        swIO.isEnabled = enabled
        swFPS.isEnabled = enabled
    }
    
    private fun startMonitoring() {
        lifecycleScope.launch {
            engine.cpuStates.collectLatest { states ->
                withContext(Dispatchers.Main) {
                    val maxFreq = states.maxOfOrNull { it.freqKhz } ?: 0
                    tvCPUCores.text = "CPU: ${states.size}核"
                    tvCPUFreq.text = String.format("%.2f GHz", maxFreq / 1e6)
                }
            }
        }
        
        lifecycleScope.launch {
            engine.gpuState.collectLatest { state ->
                withContext(Dispatchers.Main) {
                    state?.let { tvGPUFreq.text = String.format("GPU: %.0f MHz", it.freqMhz) }
                }
            }
        }
        
        lifecycleScope.launch {
            engine.temps.collectLatest { states ->
                withContext(Dispatchers.Main) {
                    val battery = states.firstOrNull { it.type.contains("battery", ignoreCase = true) }
                        ?: states.firstOrNull()
                    battery?.let {
                        tvTemp.text = String.format("温度: %.1f°C", it.tempC)
                        tvTemp.setTextColor(
                            when { it.tempC > 45f -> 0xFFF44336.toInt()
                                  it.tempC > 38f -> 0xFFFF9800.toInt()
                                  else -> 0xFF4CAF50.toInt() }
                        )
                    }
                }
            }
        }
        
        // 定时刷新
        lifecycleScope.launch {
            while (true) {
                kotlinx.coroutines.delay(2000)
                engine.updateStats()
            }
        }
    }
    
    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            swRefresh.isChecked = engine.refreshRateHz >= 144
            swSched.isChecked = engine.gpuLocked || engine.currentMode == SchedMode.HP
            swThermal.isChecked = engine.thermalDisabled
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        FpsOverlayService.stop(this)
    }
}
